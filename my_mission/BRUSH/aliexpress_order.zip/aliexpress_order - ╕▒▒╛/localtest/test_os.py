import  os
import  sys
# print(os.path.dirname(__file__))

# print(os.path.abspath(__file__))
# print(os.path.split(os.path.abspath(__file__)))
# print(os.path.split(os.path.abspath(sys.argv[0])))
print(os.path.abspath(os.path.dirname(__file__)))
print(os.path.dirname(__file__))
